#include "cuadropared.h"

cuadropared::cuadropared(SDL_Rect r, SDL_Texture* t)
{
    rect = r;
    textura = t;
}
cuadropared::~cuadropared()
{
    //dtor
}
