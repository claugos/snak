#pragma once
#include "tanque.h"

using namespace std;

void cuadro::update(){//cambiar direccion
    const Uint8 *state = SDL_GetKeyboardState(NULL);
    if (state[tDerecha]) {
        rot = 90;
        rect.x += 30;
    }
    else if (state[tIzquierda]) {
        rot = -90;
        rect.x -= 30;
    }
    else if (state[tArriba]) {
        rot = 0;
        rect.y -= 30;
    }
    else if (state[tAbajo]) {
        rot = 180;
        rect.y += 30;
    }
}

void cuadro::draw(Game *game) {
    game->draw(textura, rect, rot);
    game->drawRect(rect, 0, 1, 1);
}
cuadro::cuadro(SDL_Rect r, SDL_Texture* t,string nombre){
    Nombre = nombre;
    rect= r;
    textura = t;
    rot = 0;

}

cuadro::cuadro(Uint8 arriba, Uint8 abajo, Uint8 izquierda, Uint8 derecha, SDL_Rect r, SDL_Texture* t,string nombre) {//constructor
    tArriba = arriba;
    tAbajo = abajo;
    tIzquierda = izquierda;
    tDerecha = derecha;
    Nombre = nombre;
    rect = r;
    textura = t;
    rot = 0;
}



