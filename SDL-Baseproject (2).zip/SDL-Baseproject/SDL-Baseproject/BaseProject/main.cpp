#include <SDL.h>
#include "easydl.h"
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <map>
#include "Tanque.h"
#include "cuadropared.h"
 struct nodo{
     cuadro * valor;
     nodo * siguiente;
     nodo(){

         siguiente = nullptr;
     }
 };
 struct lista {
     nodo * inicial,*fin;

     void insertar (cuadro*m){
         nodo * nuevo = new nodo();
     nuevo -> valor = m;
         if(inicial== nullptr){
                inicial = nuevo;
                fin = inicial;
         }
         else
         {
             fin -> siguiente = nuevo;
        fin = nuevo;
         }

     }
      nodo * obtener( int j ){
         nodo *actual = inicial;
         while(j > 0 & actual != nullptr){
            actual = actual -> siguiente;
            -- j;
         }
         return actual;

     }
     lista (){
         inicial = nullptr;
         fin = nullptr;


     }
 };


int get_random(int inf, int sup){
    int j;
    j = rand() % sup + inf;
    if(j%30 == 0)
        return j;
	else
        return get_random(inf,sup);

}

using namespace std;

const int W_SCREEN = 1260;
const int H_SCREEN = 680;
const int TAM_IMAGEN = 30;

int main(int argc, char *argv[])
{
    srand (time(NULL));
    lista y;
    Game game;//se crea el objeto juego

    game.start(W_SCREEN, H_SCREEN, 50, true);
    cuadro* mat [690][630];


    // Rect destino para pintar
    SDL_Rect DestR;
    DestR.x = 60;//se puede cambiar estos parametros
    DestR.y = 30;
    DestR.w = TAM_IMAGEN;
    DestR.h = TAM_IMAGEN;

    cuadro *t = new cuadro(
        SDL_SCANCODE_UP,
        SDL_SCANCODE_DOWN,
        SDL_SCANCODE_LEFT,
        SDL_SCANCODE_RIGHT,
        DestR,
        game.loadImage("jugador.bmp"),"culebra");

         SDL_Rect DesR;
    DesR.x = 60 ;
    DesR.y = 60;
    DesR.w = TAM_IMAGEN;
    DesR.h = TAM_IMAGEN;

        cuadro *o = new cuadro(
        SDL_SCANCODE_UP,
        SDL_SCANCODE_DOWN,
        SDL_SCANCODE_LEFT,
        SDL_SCANCODE_RIGHT,
        DesR,
        game.loadImage("jugador.bmp"),"culebra");

         SDL_Rect DewR;
                //DewR.x = 90 ;
                //DewR.y = 90;

                DewR.x = get_random(30, 630) ;
                DewR.y = get_random(30, 590);
                DewR.w = 30;
                DewR.h = 30;
                cuadro* u = new cuadro(DewR,game.loadImage("manzana.png"),"comida");


    while(!game.quitEvent()){
    for(int i = 0;i < 690;i+=30)
    {
        for(int j = 0;j < 630;j+=30)
        {
            if(i ==0 or j == 0 or i==660 or j== 600 )
            {
                SDL_Rect DeR;
                DeR.x = i ;
                DeR.y = j;
                DeR.w = TAM_IMAGEN;
                DeR.h = TAM_IMAGEN;
                cuadro* T = new cuadro(DeR,game.loadImage("pared.png"),"pared");
                mat [i][j] = T;
                T->draw(&game);


            }
            else
                mat[i][j]= nullptr;
        }
    }
        u->draw(&game);
        t->update();
        t->draw(&game);
         o->update();
        o->draw(&game);
        game.update();
    }
    y.insertar(t);
    y.insertar(o);
    game.quit();

    return 0;
}
