#ifndef CUADROPARED_H
#define CUADROPARED_H
#pragma once
#include <SDL.h>
#include <string.h>
#include "Entity.h"

class cuadropared : public Entity
{
    public:
        void draw(Game *game);
        cuadropared(SDL_Rect r, SDL_Texture* t);
        virtual ~cuadropared();

};

#endif // CUADROPARED_H
