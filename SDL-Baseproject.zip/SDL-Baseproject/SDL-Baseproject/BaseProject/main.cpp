#include <SDL.h>
#include "easydl.h"
#include <iostream>
#include <string.h>
#include <map>
#include "Tanque.h"
 struct nodo{
     Tanque * valor;
     nodo * siguiente;
     nodo(){

         siguiente = nullptr;
     }
 };
 struct lista {
     nodo * inicial,*fin;

     void insertar (Tanque*m){
         nodo * nuevo = new nodo();
     nuevo -> valor = m;
         if(inicial== nullptr){
                inicial = nuevo;
                fin = inicial;
         }
         else
         {
             fin -> siguiente = nuevo;
        fin = nuevo;
         }

     }
      nodo * obtener( int j ){
         nodo *actual = inicial;
         while(j > 0 & actual != nullptr){
            actual = actual -> siguiente;
            -- j;
         }
         return actual;

     }
     lista (){
         inicial = nullptr;
         fin = nullptr;


     }
 };
using namespace std;

const int W_SCREEN = 580;
const int H_SCREEN = 420;
const int TAM_IMAGEN = 16;

int main(int argc, char *argv[])
{
    lista y;
    Game game;

    game.start(W_SCREEN, H_SCREEN, 50, true);

    // Rect destino para pintar
    SDL_Rect DestR;
    DestR.x = W_SCREEN /2  - TAM_IMAGEN /2 ;
    DestR.y = H_SCREEN / 2 - TAM_IMAGEN / 2;
    DestR.w = TAM_IMAGEN;
    DestR.h = TAM_IMAGEN;

    Tanque *t = new Tanque(
        SDL_SCANCODE_UP,
        SDL_SCANCODE_DOWN,
        SDL_SCANCODE_LEFT,
        SDL_SCANCODE_RIGHT,
        DestR,
        game.loadImage("Jugador.bmp"));

         SDL_Rect DesR;
    DesR.x = W_SCREEN /3- TAM_IMAGEN /2 ;
    DesR.y = H_SCREEN / 3 - TAM_IMAGEN / 2;
    DesR.w = TAM_IMAGEN;
    DesR.h = TAM_IMAGEN;

        Tanque *o = new Tanque(
        SDL_SCANCODE_UP,
        SDL_SCANCODE_DOWN,
        SDL_SCANCODE_LEFT,
        SDL_SCANCODE_RIGHT,
        DesR,
        game.loadImage("Jugador.bmp"));
    while(!game.quitEvent()){
        t->update();
        t->draw(&game);
         o->update();
        o->draw(&game);
        game.update();
    }
    y.insertar(t);
    y.insertar(o);
    game.quit();

    return 0;
}
