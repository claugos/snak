#pragma once
#include <SDL.h>

class Entity
{
public:
    int rot;
    SDL_Texture* textura;
    SDL_Rect rect;
};
